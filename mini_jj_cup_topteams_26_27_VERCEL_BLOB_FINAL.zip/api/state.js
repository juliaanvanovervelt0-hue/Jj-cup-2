import { put, get } from '@vercel/blob';

const PATH = 'jjcup/shared-state.json';
const DEFAULT_PASSWORD = 'JJCup2026!';

function authorized(req) {
  const expected = String(process.env.JJ_ADMIN_PASSWORD || DEFAULT_PASSWORD);
  const supplied = String(req.headers['x-jj-admin-password'] || '');
  return !!expected && supplied === expected;
}

export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
  res.setHeader('Pragma', 'no-cache');
  try {
    if (req.method === 'GET') {
      const result = await get(PATH, { access: 'private', useCache: false });
      if (!result) return res.status(404).json({ error: 'No shared state yet' });
      const text = await new Response(result.stream).text();
      return res.status(200).json(JSON.parse(text));
    }
    if (req.method === 'PUT') {
      if (!authorized(req)) return res.status(401).json({ error: 'Unauthorized' });
      if (!req.body || typeof req.body !== 'object') return res.status(400).json({ error: 'Invalid JSON body' });
      const state = { ...req.body, __savedAt: Date.now() };
      await put(PATH, JSON.stringify(state), {
        access: 'private',
        allowOverwrite: true,
        contentType: 'application/json'
      });
      return res.status(200).json(state);
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (e) {
    console.error('JJ Cup state error', e);
    return res.status(503).json({ error: 'Online storage unavailable' });
  }
}
