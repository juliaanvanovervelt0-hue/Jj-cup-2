const DEFAULT_PASSWORD = 'JJCup2026!';

export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const password = String((req.body && req.body.password) || '');
  const expected = String(process.env.JJ_ADMIN_PASSWORD || DEFAULT_PASSWORD);
  if (password !== expected) return res.status(401).json({ error: 'Invalid password' });
  return res.status(200).json({ ok: true });
}
